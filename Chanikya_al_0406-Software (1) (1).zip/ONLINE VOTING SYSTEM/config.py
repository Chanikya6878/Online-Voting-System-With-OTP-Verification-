SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://root:root@localhost/online_voting"
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = '3b4780f6f15d838736d114b769c512b2d46ef0e97fcbe12dd11290aef91190fa'

EMAIL_USER = 'user.12.asx@gmail.com'
EMAIL_PASS = 'aiqh gogh rizf yexr'

