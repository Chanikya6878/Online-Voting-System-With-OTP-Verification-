drop database online_voting;

create database online_voting;
use online_voting;