from web3 import Web3
import json

ganache_url = "http://127.0.0.1:7545"
web3 = Web3(Web3.HTTPProvider(ganache_url))

# Load ABI
with open('build/Voting.json') as f:
    abi = json.load(f)['abi']

contract_address = Web3.to_checksum_address('0x9dF46Ea6442dCd8d5466253ca6993AB1B523607b')
contract = web3.eth.contract(address=contract_address, abi=abi)

web3.eth.default_account = web3.eth.accounts[0]

def cast_vote_on_chain(user_id, candidate):
    tx = contract.functions.castVote(user_id, candidate).transact()
    receipt = web3.eth.wait_for_transaction_receipt(tx)
    return receipt
