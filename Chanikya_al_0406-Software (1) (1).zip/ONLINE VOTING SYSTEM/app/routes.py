from flask import Blueprint, render_template, request, redirect, session, flash, url_for
from .models import db, User, Vote, Candidate
from .otp_handler import generate_otp, send_otp
from .blockchain_handler import cast_vote_on_chain
from datetime import datetime

main = Blueprint('main', __name__)
otp_map = {}

# ----------------- PUBLIC -----------------

@main.route('/')
def index():
    return render_template('index.html')


@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        voter_number = request.form['voter_number']
        email = request.form['email']
        password = request.form['password']

        # Find placeholder voter by voter_number only
        voter = User.query.filter_by(voter_number=voter_number, role='voter').first()

        if not voter:
            flash('Invalid voter number.')
            return redirect('/register')

        if voter.password_hash or voter.email:
            flash('This voter has already registered.')
            return redirect('/register')

        # Set email and hashed password to complete registration
        voter.email = email
        voter.password = password  # Triggers the hashing through the @password.setter
        db.session.commit()

        flash('Registration successful. You can now log in.')
        return redirect('/login')

    return render_template('register.html')


@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        voter_number = request.form['voter_number']
        password = request.form['password']

        user = User.query.filter_by(voter_number=voter_number, role='voter').first()

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['role'] = 'voter'
            return redirect('/vote')

        flash('Invalid voter number or password.')
    return render_template('login.html')


@main.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.')
    return redirect('/')


@main.route('/vote', methods=['GET', 'POST'])
def vote():
    user_id = session.get('user_id')
    if not user_id or session.get('role') != 'voter':
        return redirect('/login')

    user = User.query.get(user_id)
    if user.has_voted:
        return "You have already voted."

    candidates = Candidate.query.all()

    if request.method == 'POST':
        if 'otp' in request.form:
            # OTP Verification Step
            entered_otp = request.form['otp']
            candidate_id = session.get('pending_vote_candidate_id')
            saved_otp = otp_map.get(user.email)

            if saved_otp and entered_otp == saved_otp:
                # OTP valid → Cast vote
                vote = Vote(user_id=user.id, candidate_id=candidate_id)
                db.session.add(vote)

                try:
                    candidate = Candidate.query.get(candidate_id)
                    cast_vote_on_chain(user.id, candidate.name)
                except Exception as e:
                    flash("Blockchain error: " + str(e))

                user.has_voted = True
                db.session.commit()
                otp_map.pop(user.email, None)
                session.pop('pending_vote_candidate_id', None)
                return render_template('success.html', candidate=candidate.name)
            else:
                flash("Invalid OTP. Please try again.")
                return render_template('vote.html', otp_sent=True, candidate_id=candidate_id, email=user.email)

        else:
            # Step 1: Candidate selection → Send OTP
            candidate_id = request.form['candidate_id']
            otp = generate_otp()
            otp_map[user.email] = otp
            send_otp(user.email, otp)

            session['pending_vote_candidate_id'] = int(candidate_id)

            flash("OTP has been sent to your email.")
            return render_template('vote.html', otp_sent=True, candidate_id=candidate_id, email=user.email)

    return render_template('vote.html', candidates=candidates, voter_number=user.voter_number)



# ----------------- ADMIN -----------------

@main.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email, role='admin').first()
        if user and user.check_password(password):
            session['admin_id'] = user.id
            session['role'] = 'admin'
            return redirect('/admin/dashboard')
        flash('Invalid admin credentials.')
    return render_template('admin_login.html')


@main.route('/admin/logout')
def admin_logout():
    session.clear()
    return redirect('/')


@main.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_id') or session.get('role') != 'admin':
        return redirect('/admin/login')

    total_voters = User.query.filter_by(role='voter').count()
    total_candidates = Candidate.query.count()
    votes_cast = Vote.query.count()

    candidates = Candidate.query.all()
    voters = User.query.filter_by(role='voter').all()

    vote_summary = {}
    for c in candidates:
        count = Vote.query.filter_by(candidate_id=c.id).count()
        vote_summary[c.name] = count

    return render_template(
        'admin_dashboard.html',
        candidates=candidates,
        voters=voters,
        vote_summary=vote_summary,
        total_voters=total_voters,
        total_candidates=total_candidates,
        votes_cast=votes_cast
    )



@main.route('/admin/add-candidate', methods=['GET', 'POST'])
def add_candidate():
    if not session.get('admin_id') or session.get('role') != 'admin':
        return redirect('/admin/login')

    if request.method == 'POST':
        name = request.form['name']
        party = request.form['party']
        if Candidate.query.filter_by(name=name).first():
            flash("Candidate already exists.")
        else:
            db.session.add(Candidate(name=name, party=party))
            db.session.commit()
            flash("Candidate added.")
        return redirect('/admin/dashboard')
    return render_template('add_candidate.html')


@main.route('/admin/add-voter', methods=['GET', 'POST'])
def add_voter():
    if not session.get('admin_id') or session.get('role') != 'admin':
        return redirect('/admin/login')

    if request.method == 'POST':
        name = request.form['name']
        voter_number = request.form['voter_number']

        if User.query.filter_by(voter_number=voter_number).first():
            flash("Voter number already exists.")
        else:
            voter = User(name=name, voter_number=voter_number, is_verified=False, has_voted=False)
            db.session.add(voter)
            db.session.commit()
            flash("Voter placeholder created successfully.")
        return redirect('/admin/dashboard')
    return render_template('add_voter.html')

@main.route('/admin/candidates')
def candidate_list():
    if not session.get('admin_id') or session.get('role') != 'admin':
        return redirect('/admin/login')
    candidates = Candidate.query.all()
    return render_template('candidate_list.html', candidates=candidates)

@main.route('/admin/voters')
def registered_voters():
    if not session.get('admin_id') or session.get('role') != 'admin':
        return redirect('/admin/login')
    voters = User.query.filter_by(role='voter').all()
    return render_template('registered_voters.html', voters=voters)
