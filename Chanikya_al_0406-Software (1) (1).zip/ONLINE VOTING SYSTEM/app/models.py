from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    password_hash = db.Column(db.String(200))  # renamed from password
    is_verified = db.Column(db.Boolean, default=False)
    has_voted = db.Column(db.Boolean, default=False)
    role = db.Column(db.String(10), default='voter')  # 'voter' or 'admin'
    voter_number = db.Column(db.String(20), unique=True, nullable=True)  # Only for voters

    votes = db.relationship('Vote', backref='user_ref', lazy=True)

    def __repr__(self):
        return f'<User {self.name} | Role={self.role} | Voter#={self.voter_number}>'

    # write-only password property
    @property
    def password(self):
        raise AttributeError("Password is not a readable field.")

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Candidate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    party = db.Column(db.String(100))

    votes = db.relationship('Vote', backref='candidate_ref', lazy=True)

    def __repr__(self):
        return f'<Candidate {self.name}>'


class Vote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Vote by User {self.user_id} for Candidate {self.candidate_id}>'
