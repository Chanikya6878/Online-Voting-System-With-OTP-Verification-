import random
import smtplib
from email.mime.text import MIMEText
from flask import current_app

def generate_otp():
    return str(random.randint(100000, 999999))

def send_otp(email, otp):
    sender = current_app.config['EMAIL_USER']
    password = current_app.config['EMAIL_PASS']
    msg = MIMEText(f"Your OTP for voting is: {otp}")
    msg['Subject'] = "Voting OTP Verification"
    msg['From'] = sender
    msg['To'] = email

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
        server.login(sender, password)
        server.sendmail(sender, email, msg.as_string())
