from app import create_app
from app.models import db, User, Candidate, Vote
from datetime import datetime
import random

app = create_app()

with app.app_context():
    db.create_all()

    # ----- Admin User -----
    admin_email = 'admin@example.com'
    if not User.query.filter_by(email=admin_email).first():
        admin = User(
            name="Admin",
            email=admin_email,
            password="admin123",  # Automatically hashed
            role="admin",
            is_verified=True
        )
        db.session.add(admin)
        print("Admin created.")
    else:
        print("Admin already exists.")

    # ----- Candidates -----
    candidate_names = [("Alice", "Party A"), ("Bob", "Party B"), ("Charlie", "Party C")]
    for name, party in candidate_names:
        if not Candidate.query.filter_by(name=name).first():
            db.session.add(Candidate(name=name, party=party))
            print(f"Candidate {name} added.")
    db.session.commit()

    candidates = Candidate.query.all()  # Fetch all for vote assignment

    # ----- Voters -----
    for i in range(1, 21):
        voter_number = f"VN{i:03d}"
        if not User.query.filter_by(voter_number=voter_number).first():
            voter = User(
                name=f"Voter{i}",
                voter_number=voter_number,
                email=f"voter{i}@example.com",
                password="test123",  # Automatically hashed
                role="voter",
                is_verified=True,
                has_voted=True
            )
            db.session.add(voter)
    db.session.commit()

    voters = User.query.filter_by(role='voter').all()

    # ----- Votes -----
    for voter in voters:
        if not Vote.query.filter_by(user_id=voter.id).first():
            candidate = random.choice(candidates)
            vote = Vote(
                user_id=voter.id,
                candidate_id=candidate.id,
                timestamp=datetime.utcnow()
            )
            db.session.add(vote)
    db.session.commit()

    print("Inserted 3 candidates, 20 voters, and 20 votes successfully.")
