import secrets

def generate_secret_key():
    key = secrets.token_hex(32)
    config_file = 'config.py'

    # Read the existing config file
    with open(config_file, 'r') as file:
        lines = file.readlines()

    # Replace the line that starts with SECRET_KEY
    with open(config_file, 'w') as file:
        for line in lines:
            if line.strip().startswith("SECRET_KEY"):
                file.write(f"SECRET_KEY = '{key}'\n")
            else:
                file.write(line)

    print(f"SECRET_KEY updated successfully in config.py:\n{key}")

if __name__ == "__main__":
    generate_secret_key()
